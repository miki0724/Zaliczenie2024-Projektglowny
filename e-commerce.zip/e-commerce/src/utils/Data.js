export const services = [
  {
    title: "Darmowa dostawa!",
    tagline: "Dla zamówień powyżej 99zł",
    image: "images/service.png",
  },
  {
    title: "Codzienne promocje",
    tagline: "Nawet do 40%",
    image: "images/service-02.png",
  },
  {
    title: "Obsługa klienta",
    tagline: "Przez 24h/7 dni w tygodniu ",
    image: "images/service-03.png",
  },
];
