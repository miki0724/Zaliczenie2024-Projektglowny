const productDataPromocja = [
  {
    id: 1,
    nameK: "Hortex  ",
    name: "Mieszanka warzywna",
    image: "../images/meksyk.jpg",
    price: 5.49,
    stara: 8.59,
    rating: 5,
    description:
      "warzywa w zmiennych proporcjach: marchew, fasola szparagowa, KUKURYDZA, groch zielony, papryka, fasola czerwona blanszowana, cebula",
    ilosc: 220,
  },
  {
    id: 2,
    nameK: "BATOM ",
    name: "Maca",
    image: "../images/maca.jpg",
    price: 19.99,
    stara: 22.59,
    rating: 5,
    description:
      "Ekologiczne migdały to doskonały produkt do spożywania pod każdą postacią. Polecamy jako samodzielną przekąskę w szkole lub w pracy, a także jako dodatek do wypieków, deserów, musli, do porannej owsianki oraz likierów i nalewek owocowych.",

    ilosc: 16,
  },
  {
    id: 3,
    nameK: "Bio Planet",
    name: "Jogurt proteinowya",
    image: "../images/jogurt.jpg",
    price: 2.55,
    stara: 4.59,
    rating: 5,
    description:
      "Ekologiczne orzechy nerkowca charakteryzują się delikatnym, lekko słodkim smakiem. Stanowią pożywną przekąskę, a także ciekawy dodatek do duszonych lub pieczonych warzyw, ciast, deserów i sałatek.",

    ilosc: 22220,
  },
  {
    id: 4,
    nameK: "Perła",
    name: "Piwo bezalkoholowe ",
    image: "../images/perla.webp",
    price: 3.59,
    stara: 6.59,
    rating: 5,
    description:
      "Ekologiczne ORZECHY WŁOSKIE charakteryzują się ciekawym słodko-gorzkim smakiem. Polecamy jako dodatek do sałatek (najlepiej lekko podprażone) lub jako samodzielną przekąskę.",

    ilosc: 331,
  },
];
export default productDataPromocja;
