const productDataHit = [
  {
    id: 1,
    nameK: "Targroch  ",
    name: "Erytrol",
    image: "../images/erytrol.webp",
    price: 45.09,
    rating: 5,
    description:
      "Erytrytol to poliol o słodkim smaku, zbliżonym do smaku zwykłego buraczanego cukru. Charakteryzuje go znikoma kaloryczność wynosząca w przybliżeniu 0 kcal. Używany w nadmiarze może wywołać efekt przeczyszczający lub przyspieszający materię zwłaszcza dla osób nieprzyzwyczajonych. ",
  },
  {
    id: 2,
    nameK: "Rabenhorst",
    name: "Bogactwo Żelaza",
    image: "../images/plus.webp",
    price: 27.37,
    rating: 5,
    description:
      "sok bogactwo żelaza sprawdził się podczas mojej pierwszej i drugiej ciąży w których miałam niedobór żelaza a nie chciałam brać tabletek, dlatego polecam zwłaszcza wszystkim kobietom w ciąży i innym osobom cierpiącym na niedobór żelaza",
  },
  {
    id: 3,
    nameK: "Yango",
    name: "Dziurawiec 90 Kapsułek",
    image: "../images/dziurawiec.webp",
    price: 36.99,
    rating: 5,
    description:
      "zalecane dzienne spożycie: 1 kapsułka raz dziennie. Kapsułkę połknąć i popić dużą ilością wody, po posiłku. Nie należy przekraczać zalecanej porcji do spożycia w ciągu dnia.",
  },
  {
    id: 4,
    nameK: "Bioagros",
    name: "Dolmadakia (Greckie Gołąbki)",
    image: "../images/dolma.webp",
    price: 21.99,
    rating: 5,
    description: "Dolmadakia (Greckie Gołąbki)",
  },
];
export default productDataHit;
